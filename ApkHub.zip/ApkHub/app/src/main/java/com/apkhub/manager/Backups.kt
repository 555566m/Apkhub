package com.apkhub.manager

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object Backups {
    /** Single APK -> .apk, split app -> .apks (zip of all splits, installable again by APK Hub). */
    fun backup(ctx: Context, app: AppItem, tree: Uri) {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: error("Backup folder not accessible")
        val safe = app.name.replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_').ifEmpty { app.packageName }
        val ver = app.versionName.ifEmpty { app.versionCode.toString() }
        val split = app.sourceDirs.size > 1
        val fileName = "${safe}_${ver}_${app.packageName}" + if (split) ".apks" else ".apk"

        dir.findFile(fileName)?.delete()
        val mime = if (split) "application/octet-stream" else "application/vnd.android.package-archive"
        val out = dir.createFile(mime, fileName) ?: error("Cannot create backup file")
        val os = ctx.contentResolver.openOutputStream(out.uri, "w") ?: error("Cannot write backup file")
        os.use {
            if (!split) {
                File(app.sourceDirs[0]).inputStream().use { ins -> ins.copyTo(os) }
            } else {
                ZipOutputStream(os.buffered()).use { zip ->
                    zip.setLevel(0)
                    app.sourceDirs.forEach { p ->
                        val f = File(p)
                        zip.putNextEntry(ZipEntry(f.name))
                        f.inputStream().use { ins -> ins.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
        }
    }

    fun list(ctx: Context, tree: Uri): List<FileEntry> {
        val dir = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        return dir.listFiles()
            .filter { it.isFile && isApkLike(it.name ?: "") }
            .map { FileEntry(it.name!!, it.uri, it.length(), it.lastModified()) }
            .sortedByDescending { it.modified }
    }

    fun delete(ctx: Context, uri: Uri): Boolean =
        DocumentFile.fromSingleUri(ctx, uri)?.delete() ?: false
}

object Scanner {
    /** Fast recursive scan of a folder picked via the system picker (works on every Android version). */
    fun scanTree(ctx: Context, tree: Uri, maxDepth: Int = 6): List<FileEntry> {
        val out = mutableListOf<FileEntry>()
        fun walk(docId: String, depth: Int) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val dirs = mutableListOf<String>()
            ctx.contentResolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                ), null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < maxDepth) dirs += id
                    } else if (isApkLike(name)) {
                        out += FileEntry(name, DocumentsContract.buildDocumentUriUsingTree(tree, id), c.getLong(3), c.getLong(4))
                    }
                }
            }
            dirs.forEach { walk(it, depth + 1) }
        }
        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return out.sortedByDescending { it.modified }
    }

    /** Full phone scan (needs "All files access"). Skips Android/ and hidden folders. */
    fun scanStorage(limit: Int = 1500): List<FileEntry> {
        val root = Environment.getExternalStorageDirectory()
        return root.walkTopDown()
            .onEnter { d -> !(d.name == "Android" && d.parentFile == root) && !d.name.startsWith(".") }
            .filter { it.isFile && isApkLike(it.name) }
            .take(limit)
            .map { FileEntry(it.name, Uri.fromFile(it), it.length(), it.lastModified()) }
            .toList()
            .sortedByDescending { it.modified }
    }
}
