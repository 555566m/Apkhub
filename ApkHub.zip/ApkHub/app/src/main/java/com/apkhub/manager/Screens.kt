@file:OptIn(ExperimentalFoundationApi::class)

package com.apkhub.manager

import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ───────────────────────── root ─────────────────────────

private class NavItem(val label: String, val icon: @Composable () -> Unit)

private val navItems = listOf(
    NavItem("Apps") { Icon(painterResource(R.drawable.ic_apps), null) },
    NavItem("Install") { Icon(painterResource(R.drawable.ic_download), null) },
    NavItem("Backups") { Icon(painterResource(R.drawable.ic_restore), null) },
    NavItem("Settings") { Icon(Icons.Default.Settings, null) },
)

@Composable
fun AppRoot(vm: MainViewModel, act: Actions) {
    ApkHubTheme(vm.themeMode, vm.palette) {
        var tab by rememberSaveable { mutableStateOf(0) }
        val snack = remember { SnackbarHostState() }
        LaunchedEffect(Unit) { vm.toast.collect { snack.showSnackbar(it) } }
        BackHandler(enabled = vm.selected.isNotEmpty()) { vm.selected = emptySet() }

        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                NavigationBar {
                    navItems.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = item.icon,
                            label = { Text(item.label) },
                        )
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> AppsScreen(vm, act)
                    1 -> InstallScreen(vm, act)
                    2 -> BackupsScreen(vm, act)
                    else -> SettingsScreen(vm, act)
                }
            }
        }
        vm.working?.let { WorkingDialog(it) }
    }
}

@Composable
private fun WorkingDialog(msg: String) {
    AlertDialog(
        onDismissRequest = {},
        confirmButton = {},
        title = { Text("Please wait") },
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(16.dp))
                Text(msg)
            }
        },
    )
}

// ───────────────────────── shared bits ─────────────────────────

private object IconCache {
    private val cache = LruCache<String, ImageBitmap>(250)
    fun get(pkg: String): ImageBitmap? = cache.get(pkg)
    fun load(ctx: android.content.Context, pkg: String): ImageBitmap? = try {
        ctx.packageManager.getApplicationIcon(pkg).toBitmap(112, 112).asImageBitmap().also { cache.put(pkg, it) }
    } catch (e: Exception) {
        null
    }
}

@Composable
private fun AppIcon(pkg: String, size: androidx.compose.ui.unit.Dp = 48.dp) {
    val ctx = LocalContext.current
    val bmp by produceState(IconCache.get(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.IO) { IconCache.load(ctx, pkg) }
    }
    val shape = RoundedCornerShape(12.dp)
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = Modifier.size(size).clip(shape))
    } else {
        Box(Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant))
    }
}

@Composable
private fun ScreenTitle(title: String, sub: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            if (sub != null) {
                Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        trailing()
    }
}

@Composable
private fun StatBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun InfoCard(content: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        modifier = Modifier.fillMaxWidth(),
    ) { Column(Modifier.padding(16.dp)) { content() } }
}

private val listPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp)

// ───────────────────────── Apps ─────────────────────────

@Composable
private fun AppsScreen(vm: MainViewModel, act: Actions) {
    val list = remember(vm.allApps, vm.query, vm.filter, vm.sort) { vm.visible() }
    val totalApk = list.sumOf { it.apkSize }
    val totalCache = list.filter { it.cacheSize >= 0 }.sumOf { it.cacheSize }
    val selecting = vm.selected.isNotEmpty()

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = if (selecting) 96.dp else 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                ScreenTitle("Apps", if (vm.loading) "Loading…" else "${list.size} apps") {
                    IconButton(onClick = { vm.refresh() }) { Icon(Icons.Default.Refresh, "Refresh") }
                }
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        StatBlock("Apps", list.size.toString(), Modifier.weight(1f))
                        StatBlock("APK size", fmtSize(totalApk), Modifier.weight(1f))
                        StatBlock("Cache", if (vm.usageGranted) fmtSize(totalCache) else "—", Modifier.weight(1f))
                    }
                }
            }
            if (!vm.usageGranted) {
                item {
                    InfoCard {
                        Text("See cache & data size", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Android needs “Usage access” to show cache and data size of other apps.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(8.dp))
                        FilledTonalButton(onClick = act.openUsageAccess) { Text("Grant access") }
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.query = it },
                    placeholder = { Text("Search apps") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (vm.query.isNotEmpty()) {
                            IconButton(onClick = { vm.query = "" }) { Icon(Icons.Default.Close, "Clear") }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item { FilterRow(vm) }
            items(list, key = { it.packageName }) { app ->
                AppRow(
                    app = app,
                    showUsage = vm.usageGranted,
                    selected = app.packageName in vm.selected,
                    selecting = selecting,
                    onToggle = { vm.toggleSelect(app.packageName) },
                    act = act,
                )
            }
        }

        AnimatedVisibility(
            visible = selecting,
            modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
        ) {
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                shadowElevation = 8.dp,
            ) {
                Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.selected = emptySet() }) { Icon(Icons.Default.Close, "Cancel") }
                    Text("${vm.selected.size}", fontWeight = FontWeight.Bold)
                    TextButton(onClick = { vm.selected = list.map { it.packageName }.toSet() }) { Text("All") }
                    Spacer(Modifier.weight(1f))
                    FilledTonalButton(onClick = { act.backup(vm.selected.toList()) }) { Text("Backup") }
                    Spacer(Modifier.width(6.dp))
                    Button(
                        onClick = { act.uninstall(vm.selected.toList()) },
                        colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError,
                        ),
                    ) { Text("Uninstall") }
                }
            }
        }
    }
}

@Composable
private fun FilterRow(vm: MainViewModel) {
    var sortMenu by remember { mutableStateOf(false) }
    val sortNames = listOf("Name", "Size", "Cache", "Recent")
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        listOf("User", "System", "All").forEachIndexed { i, name ->
            FilterChip(selected = vm.filter == i, onClick = { vm.changeFilter(i) }, label = { Text(name) })
        }
        Box {
            TextButton(onClick = { sortMenu = true }) { Text("Sort: ${sortNames[vm.sort]}") }
            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                sortNames.forEachIndexed { i, n ->
                    DropdownMenuItem(text = { Text(n) }, onClick = { vm.changeSort(i); sortMenu = false })
                }
            }
        }
    }
}

@Composable
private fun AppRow(
    app: AppItem,
    showUsage: Boolean,
    selected: Boolean,
    selecting: Boolean,
    onToggle: () -> Unit,
    act: Actions,
) {
    var menu by remember { mutableStateOf(false) }
    val shape = MaterialTheme.shapes.medium
    val primary = MaterialTheme.colorScheme.primary
    Surface(
        shape = shape,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .combinedClickable(
                onClick = { if (selecting) onToggle() else menu = true },
                onLongClick = onToggle,
            ),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.BottomEnd) {
                AppIcon(app.packageName)
                if (selected) {
                    Box(
                        Modifier.size(20.dp).clip(CircleShape).background(primary),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(14.dp)) }
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(app.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "v${app.versionName} · ${app.packageName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    buildAnnotatedString {
                        append("APK ${fmtSize(app.apkSize)}")
                        if (showUsage && app.cacheSize >= 0) {
                            append("  •  ")
                            withStyle(SpanStyle(color = primary, fontWeight = FontWeight.SemiBold)) {
                                append("Cache ${fmtSize(app.cacheSize)}")
                            }
                            append("  •  Data ${fmtSize(app.dataSize)}")
                        }
                    },
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 2,
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; act.openApp(app.packageName) })
                    DropdownMenuItem(
                        text = { Text("App info / clear cache") },
                        onClick = { menu = false; act.openAppInfo(app.packageName) },
                    )
                    DropdownMenuItem(text = { Text("Backup APK") }, onClick = { menu = false; act.backup(listOf(app.packageName)) })
                    DropdownMenuItem(text = { Text("Select") }, onClick = { menu = false; onToggle() })
                    if (!app.isSystem) {
                        DropdownMenuItem(
                            text = { Text("Uninstall", color = MaterialTheme.colorScheme.error) },
                            onClick = { menu = false; act.uninstall(listOf(app.packageName)) },
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────────── Install ─────────────────────────

@Composable
private fun InstallScreen(vm: MainViewModel, act: Actions) {
    var sel by remember { mutableStateOf(setOf<Uri>()) }
    LazyColumn(contentPadding = listPadding, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenTitle("Install", "APK, APKS, XAPK, APKM — from any folder") }
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(painterResource(R.drawable.ic_download), null, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Pick files to install", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "You can select many at once.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = act.pickApks) { Text("Choose files") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = act.pickScanFolder, modifier = Modifier.weight(1f)) {
                    Icon(painterResource(R.drawable.ic_folder), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Scan folder")
                }
                OutlinedButton(onClick = act.scanPhone, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Search, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Scan phone")
                }
            }
        }
        item {
            Text(
                "Tip: open any .apk from your file manager or browser and choose APK Hub.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (vm.scanning) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (vm.found.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${vm.found.size} files found", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    if (sel.isNotEmpty()) {
                        Button(onClick = { act.install(sel.toList()); sel = emptySet() }) { Text("Install ${sel.size}") }
                    } else {
                        TextButton(onClick = { sel = vm.found.map { it.uri }.toSet() }) { Text("Select all") }
                    }
                }
            }
            items(vm.found, key = { it.uri.toString() }) { f ->
                FileRow(
                    f = f,
                    checked = f.uri in sel,
                    onCheck = { sel = if (f.uri in sel) sel - f.uri else sel + f.uri },
                    actionLabel = "Install",
                    onAction = { act.install(listOf(f.uri)) },
                )
            }
        }
    }
}

@Composable
private fun FileRow(
    f: FileEntry,
    checked: Boolean?,
    onCheck: () -> Unit = {},
    actionLabel: String,
    onAction: () -> Unit,
    onDelete: (() -> Unit)? = null,
) {
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 6.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (checked != null) Checkbox(checked = checked, onCheckedChange = { onCheck() })
            else Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    listOf(fmtSize(f.size), fmtDate(f.modified)).filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            FilledTonalButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 14.dp)) { Text(actionLabel) }
            if (onDelete != null) {
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

// ───────────────────────── Backups ─────────────────────────

@Composable
private fun BackupsScreen(vm: MainViewModel, act: Actions) {
    LaunchedEffect(vm.backupTree) { vm.loadBackups() }
    val folderName = vm.backupTree?.lastPathSegment?.substringAfterLast(':')?.ifEmpty { "Storage root" }

    LazyColumn(contentPadding = listPadding, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            ScreenTitle("Backups", "${vm.backups.size} files") {
                IconButton(onClick = { vm.loadBackups() }) { Icon(Icons.Default.Refresh, "Refresh") }
            }
        }
        item {
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_folder), null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Backup folder", style = MaterialTheme.typography.labelMedium)
                        Text(folderName ?: "Not selected", fontWeight = FontWeight.SemiBold)
                    }
                    FilledTonalButton(onClick = act.pickBackupFolder) { Text(if (folderName == null) "Choose" else "Change") }
                }
            }
        }
        if (vm.backups.isEmpty()) {
            item {
                Text(
                    "No backups yet. Long-press apps in the Apps tab, select them and tap Backup.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(8.dp),
                )
            }
        }
        items(vm.backups, key = { it.uri.toString() }) { f ->
            FileRow(
                f = f,
                checked = null,
                actionLabel = "Restore",
                onAction = { act.install(listOf(f.uri)) },
                onDelete = { vm.deleteBackup(f) },
            )
        }
    }
}

// ───────────────────────── Settings ─────────────────────────

@Composable
private fun SettingsScreen(vm: MainViewModel, act: Actions) {
    LazyColumn(contentPadding = listPadding, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenTitle("Settings", "Make it yours") }
        item {
            InfoCard {
                Text("Theme", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("System", "Light", "Dark", "AMOLED").forEachIndexed { i, n ->
                        FilterChip(selected = vm.themeMode == i, onClick = { vm.changeThemeMode(i) }, label = { Text(n) })
                    }
                }
            }
        }
        item {
            InfoCard {
                Text("Accent colour", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (Build.VERSION.SDK_INT >= 31) {
                        Swatch(
                            brush = Brush.sweepGradient(listOf(Color(0xFFEA4335), Color(0xFFFBBC04), Color(0xFF34A853), Color(0xFF4285F4), Color(0xFFEA4335))),
                            selected = vm.palette == 0, label = "Dynamic",
                        ) { vm.changePalette(0) }
                    }
                    Palettes.forEachIndexed { i, p ->
                        Swatch(brush = Brush.linearGradient(listOf(p.light, p.light)), selected = vm.palette == i + 1, label = p.name) {
                            vm.changePalette(i + 1)
                        }
                    }
                }
            }
        }
        item {
            InfoCard {
                Text("Cache & data sizes", fontWeight = FontWeight.SemiBold)
                Text(
                    if (vm.usageGranted) "Usage access granted ✓" else "Usage access is off — cache/data sizes are hidden.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                FilledTonalButton(onClick = act.openUsageAccess) { Text(if (vm.usageGranted) "Manage" else "Grant access") }
            }
        }
        item {
            InfoCard {
                Text("About", fontWeight = FontWeight.SemiBold)
                Text(
                    "APK Hub 1.0 — open source APK installer, backup & manager.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun Swatch(brush: Brush, selected: Boolean, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(brush)
                .then(if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Icon(Icons.Default.Check, null, tint = Color.White)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
