package com.apkhub.manager

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.util.zip.ZipInputStream

object ApkInstaller {
    const val ACTION = "com.apkhub.manager.INSTALL_RESULT"

    private val knownAbis = setOf("arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64")

    fun displayName(ctx: Context, uri: Uri): String {
        if (uri.scheme == "content") {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { return it }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "app.apk"
    }

    private fun sizeOf(ctx: Context, uri: Uri): Long {
        if (uri.scheme == "content") {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
            return -1
        }
        return uri.path?.let { File(it).length() } ?: -1
    }

    /** Skip CPU-ABI split APKs that do not match this device. */
    private fun skipSplit(entryName: String): Boolean {
        val n = entryName.lowercase().removeSuffix(".apk").substringAfter("config.", "")
        if (n.isEmpty() || n !in knownAbis) return false
        val device = Build.SUPPORTED_ABIS.map { it.replace('-', '_').lowercase() }
        return n !in device
    }

    /** Installs a single .apk or a bundle (.apks / .xapk / .apkm). Throws on failure before commit. */
    suspend fun install(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val resolver = ctx.contentResolver
        val name = displayName(ctx, uri).lowercase()
        val bundle = name.endsWith(".apks") || name.endsWith(".xapk") ||
            name.endsWith(".apkm") || name.endsWith(".zip")

        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) {
            params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        }
        val id = installer.createSession(params)
        try {
            installer.openSession(id).use { session ->
                var written = 0
                if (bundle) {
                    val raw = resolver.openInputStream(uri) ?: error("Cannot open file")
                    ZipInputStream(BufferedInputStream(raw)).use { zis ->
                        var e = zis.nextEntry
                        while (e != null) {
                            val entryName = e.name.substringAfterLast('/')
                            if (!e.isDirectory && entryName.endsWith(".apk", true) && !skipSplit(entryName)) {
                                session.openWrite(entryName, 0, -1).use { out ->
                                    zis.copyTo(out)
                                    session.fsync(out)
                                }
                                written++
                            }
                            zis.closeEntry()
                            e = zis.nextEntry
                        }
                    }
                } else {
                    val input = resolver.openInputStream(uri) ?: error("Cannot open file")
                    input.use { ins ->
                        session.openWrite("base.apk", 0, sizeOf(ctx, uri)).use { out ->
                            ins.copyTo(out)
                            session.fsync(out)
                        }
                    }
                    written = 1
                }
                if (written == 0) error("No APK found inside this file")

                val intent = Intent(ctx, InstallReceiver::class.java).setAction(ACTION)
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val pi = PendingIntent.getBroadcast(ctx, id, intent, flags)
                session.commit(pi.intentSender)
            }
        } catch (t: Throwable) {
            runCatching { installer.abandonSession(id) }
            throw t
        }
    }
}

class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                }
                confirm?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(it)
                }
            }
            PackageInstaller.STATUS_SUCCESS -> Bus.events.tryEmit(InstallEvent(true, "Installed successfully"))
            else -> {
                val msg = when (status) {
                    PackageInstaller.STATUS_FAILURE_ABORTED -> "Install cancelled"
                    PackageInstaller.STATUS_FAILURE_CONFLICT ->
                        "Conflicts with an installed app (different signature?). Uninstall the old one first."
                    PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> "Not compatible with this device"
                    PackageInstaller.STATUS_FAILURE_STORAGE -> "Not enough storage"
                    PackageInstaller.STATUS_FAILURE_INVALID -> "Invalid or corrupted APK"
                    PackageInstaller.STATUS_FAILURE_BLOCKED -> "Blocked by the system"
                    else -> intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Install failed ($status)"
                }
                Bus.events.tryEmit(InstallEvent(false, msg))
            }
        }
    }
}
