package com.apkhub.manager

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

class Palette(val name: String, val light: Color, val dark: Color, val lightC: Color, val darkC: Color)

val Palettes = listOf(
    Palette("Ocean", Color(0xFF0061A4), Color(0xFF9ECAFF), Color(0xFFD1E4FF), Color(0xFF00497D)),
    Palette("Forest", Color(0xFF1B6D3B), Color(0xFF86D99C), Color(0xFFA2F5B6), Color(0xFF00522A)),
    Palette("Sunset", Color(0xFF9C4A00), Color(0xFFFFB783), Color(0xFFFFDCC6), Color(0xFF763500)),
    Palette("Violet", Color(0xFF6750A4), Color(0xFFD0BCFF), Color(0xFFEADDFF), Color(0xFF4F378B)),
    Palette("Rose", Color(0xFFA9366F), Color(0xFFFFB0D2), Color(0xFFFFD8E8), Color(0xFF8A1853)),
    Palette("Slate", Color(0xFF455A64), Color(0xFFB0BEC5), Color(0xFFCFD8DC), Color(0xFF37474F)),
)

private fun buildScheme(p: Palette, dark: Boolean): ColorScheme =
    if (dark) darkColorScheme(
        primary = p.dark, onPrimary = p.darkC,
        primaryContainer = p.darkC, onPrimaryContainer = p.lightC,
        secondary = p.dark, onSecondary = p.darkC,
        secondaryContainer = p.darkC, onSecondaryContainer = p.lightC,
        tertiary = p.dark, onTertiary = p.darkC,
        tertiaryContainer = p.darkC, onTertiaryContainer = p.lightC,
        background = Color(0xFF101114), onBackground = Color(0xFFE3E2E6),
        surface = Color(0xFF101114), onSurface = Color(0xFFE3E2E6),
        surfaceVariant = Color(0xFF2A2C31), onSurfaceVariant = Color(0xFFC4C6D0),
        surfaceContainerLowest = Color(0xFF0B0C0E), surfaceContainerLow = Color(0xFF191A1E),
        surfaceContainer = Color(0xFF1D1E22), surfaceContainerHigh = Color(0xFF282A2E),
        surfaceContainerHighest = Color(0xFF333539),
        outline = Color(0xFF8E9099), outlineVariant = Color(0xFF44474E),
    ) else lightColorScheme(
        primary = p.light, onPrimary = Color.White,
        primaryContainer = p.lightC, onPrimaryContainer = p.darkC,
        secondary = p.light, onSecondary = Color.White,
        secondaryContainer = p.lightC, onSecondaryContainer = p.darkC,
        tertiary = p.light, onTertiary = Color.White,
        tertiaryContainer = p.lightC, onTertiaryContainer = p.darkC,
        background = Color(0xFFFAFAFC), onBackground = Color(0xFF1B1B1F),
        surface = Color(0xFFFAFAFC), onSurface = Color(0xFF1B1B1F),
        surfaceVariant = Color(0xFFE1E2EC), onSurfaceVariant = Color(0xFF44474E),
        surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF2F3F7),
        surfaceContainer = Color(0xFFEDEEF2), surfaceContainerHigh = Color(0xFFE7E8ED),
        surfaceContainerHighest = Color(0xFFE1E2E7),
        outline = Color(0xFF74777F), outlineVariant = Color(0xFFC4C6D0),
    )

@Composable
fun ApkHubTheme(mode: Int, palette: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2, 3 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    var scheme = if (palette == 0 && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        buildScheme(Palettes[(palette - 1).coerceIn(0, Palettes.lastIndex)], dark)
    }
    if (mode == 3) {
        scheme = scheme.copy(
            background = Color.Black, surface = Color.Black,
            surfaceContainerLowest = Color.Black, surfaceContainerLow = Color(0xFF0B0B0B),
            surfaceContainer = Color(0xFF121212), surfaceContainerHigh = Color(0xFF1A1A1A),
            surfaceContainerHighest = Color(0xFF222222),
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(26.dp),
        ),
        content = content,
    )
}
