package com.apkhub.manager

import android.content.Context
import android.os.Build

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("apkhub", Context.MODE_PRIVATE)

    /** 0 = system, 1 = light, 2 = dark, 3 = AMOLED black */
    var themeMode: Int
        get() = sp.getInt("mode", 0)
        set(v) = sp.edit().putInt("mode", v).apply()

    /** 0 = Material You (Android 12+), 1.. = built-in palettes */
    var palette: Int
        get() = sp.getInt("palette", if (Build.VERSION.SDK_INT >= 31) 0 else 1)
        set(v) = sp.edit().putInt("palette", v).apply()

    /** 0 = user apps, 1 = system apps, 2 = all */
    var filter: Int
        get() = sp.getInt("filter", 0)
        set(v) = sp.edit().putInt("filter", v).apply()

    /** 0 = name, 1 = size, 2 = cache, 3 = recent */
    var sort: Int
        get() = sp.getInt("sort", 0)
        set(v) = sp.edit().putInt("sort", v).apply()

    var backupTree: String?
        get() = sp.getString("tree", null)
        set(v) = sp.edit().putString("tree", v).apply()
}
