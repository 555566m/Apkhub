package com.apkhub.manager

import android.net.Uri
import kotlinx.coroutines.flow.MutableSharedFlow
import java.text.DateFormat
import java.util.Date
import java.util.Locale

data class AppItem(
    val packageName: String,
    val name: String,
    val versionName: String,
    val versionCode: Long,
    val isSystem: Boolean,
    val apkSize: Long,
    val dataSize: Long = -1,
    val cacheSize: Long = -1,
    val installTime: Long,
    val updateTime: Long,
    val sourceDirs: List<String>,
)

data class FileEntry(val name: String, val uri: Uri, val size: Long, val modified: Long)

data class InstallEvent(val ok: Boolean, val text: String)

/** Install results from [InstallReceiver] are pushed here and picked up by the ViewModel. */
object Bus {
    val events = MutableSharedFlow<InstallEvent>(extraBufferCapacity = 16)
}

class Actions(
    val pickApks: () -> Unit,
    val pickScanFolder: () -> Unit,
    val scanPhone: () -> Unit,
    val install: (List<Uri>) -> Unit,
    val backup: (List<String>) -> Unit,
    val pickBackupFolder: () -> Unit,
    val uninstall: (List<String>) -> Unit,
    val openUsageAccess: () -> Unit,
    val openAppInfo: (String) -> Unit,
    val openApp: (String) -> Unit,
)

fun fmtSize(b: Long): String {
    if (b < 0) return "—"
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
}

fun fmtDate(ms: Long): String =
    if (ms <= 0) "" else DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

fun isApkLike(name: String): Boolean {
    val n = name.lowercase()
    return n.endsWith(".apk") || n.endsWith(".apks") || n.endsWith(".xapk") || n.endsWith(".apkm")
}
