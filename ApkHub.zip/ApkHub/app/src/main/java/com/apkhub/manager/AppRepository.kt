package com.apkhub.manager

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import androidx.core.content.pm.PackageInfoCompat
import java.io.File

object AppRepository {

    /** Cache / data sizes of other apps are only readable with "Usage access". */
    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun loadBase(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        return pm.getInstalledPackages(0).mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            val dirs = buildList {
                add(ai.sourceDir)
                ai.splitSourceDirs?.let { addAll(it) }
            }
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppItem(
                packageName = pi.packageName,
                name = ai.loadLabel(pm).toString(),
                versionName = pi.versionName ?: "",
                versionCode = PackageInfoCompat.getLongVersionCode(pi),
                isSystem = isSystem,
                apkSize = dirs.sumOf { File(it).length() },
                installTime = pi.firstInstallTime,
                updateTime = pi.lastUpdateTime,
                sourceDirs = dirs,
            )
        }
    }

    fun withStats(ctx: Context, a: AppItem): AppItem = try {
        val ssm = ctx.getSystemService(StorageStatsManager::class.java)
        val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, a.packageName, Process.myUserHandle())
        a.copy(dataSize = s.dataBytes, cacheSize = s.cacheBytes)
    } catch (e: Exception) {
        a
    }
}
