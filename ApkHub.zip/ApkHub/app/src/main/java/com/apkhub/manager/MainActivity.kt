package com.apkhub.manager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private var pendingInstall: List<Uri> = emptyList()
    private var pendingBackup: List<String> = emptyList()
    private val uninstallQueue = ArrayDeque<String>()

    private val pickApks = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) install(it)
    }
    private val pickScanFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) {
        it?.let(vm::scanFolder)
    }
    private val pickBackupFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            vm.changeBackupTree(uri)
            if (pendingBackup.isNotEmpty()) {
                vm.backupSelected(pendingBackup)
                pendingBackup = emptyList()
            }
        } else pendingBackup = emptyList()
    }
    private val unknownSources = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (packageManager.canRequestPackageInstalls() && pendingInstall.isNotEmpty()) {
            vm.enqueueInstall(pendingInstall)
        }
        pendingInstall = emptyList()
    }
    private val uninstallLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.refresh()
        nextUninstall()
    }
    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) vm.scanStorage()
    }
    private val allFilesSettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (hasAllFiles()) vm.scanStorage()
    }
    private val usageSettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val actions = Actions(
            pickApks = { pickApks.launch(arrayOf("*/*")) },
            pickScanFolder = { pickScanFolder.launch(null) },
            scanPhone = ::scanPhone,
            install = ::install,
            backup = ::backup,
            pickBackupFolder = ::chooseBackupFolder,
            uninstall = ::uninstall,
            openUsageAccess = { usageSettings.launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
            openAppInfo = { pkg ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            },
            openApp = { pkg -> packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) } },
        )
        setContent { AppRoot(vm, actions) }

        if (savedInstanceState == null) handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** An .apk opened from a file manager / browser. */
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) i.data?.let { install(listOf(it)) }
    }

    private fun install(uris: List<Uri>) {
        if (!packageManager.canRequestPackageInstalls()) {
            pendingInstall = uris
            Toast.makeText(this, "Allow \"Install unknown apps\" for APK Hub", Toast.LENGTH_LONG).show()
            unknownSources.launch(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
        } else vm.enqueueInstall(uris)
    }

    private fun uninstall(pkgs: List<String>) {
        vm.selected = emptySet()
        uninstallQueue.clear()
        uninstallQueue.addAll(pkgs)
        nextUninstall()
    }

    private fun nextUninstall() {
        val p = uninstallQueue.removeFirstOrNull() ?: return
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$p")).putExtra(Intent.EXTRA_RETURN_RESULT, true)
        runCatching { uninstallLauncher.launch(i) }.onFailure { nextUninstall() }
    }

    private fun chooseBackupFolder() {
        Toast.makeText(this, "Pick or create a folder, e.g. “APK Backups”", Toast.LENGTH_LONG).show()
        pickBackupFolder.launch(null)
    }

    private fun backup(pkgs: List<String>) {
        if (vm.backupTree == null) {
            pendingBackup = pkgs
            chooseBackupFolder()
        } else vm.backupSelected(pkgs)
    }

    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun scanPhone() {
        when {
            Build.VERSION.SDK_INT >= 30 ->
                if (hasAllFiles()) vm.scanStorage()
                else allFilesSettings.launch(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            // Android 10 enforces scoped storage: use the folder picker instead.
            Build.VERSION.SDK_INT == 29 -> pickScanFolder.launch(null)
            hasAllFiles() -> vm.scanStorage()
            else -> storagePerm.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
}
