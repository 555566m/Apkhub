package com.apkhub.manager

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var themeMode by mutableIntStateOf(prefs.themeMode)
        private set
    var palette by mutableIntStateOf(prefs.palette)
        private set
    var filter by mutableIntStateOf(prefs.filter)
        private set
    var sort by mutableIntStateOf(prefs.sort)
        private set

    var allApps by mutableStateOf<List<AppItem>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var usageGranted by mutableStateOf(false)
        private set

    var query by mutableStateOf("")
    var selected by mutableStateOf<Set<String>>(emptySet())

    var backupTree by mutableStateOf(prefs.backupTree?.let { Uri.parse(it) })
        private set
    var backups by mutableStateOf<List<FileEntry>>(emptyList())
        private set
    var found by mutableStateOf<List<FileEntry>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set
    var working by mutableStateOf<String?>(null)
        private set

    val toast = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private val installQueue = ArrayDeque<Uri>()
    private var installing = false
    private var refreshJob: Job? = null

    init {
        refresh()
        viewModelScope.launch {
            Bus.events.collect { ev ->
                toast.tryEmit(ev.text)
                if (installing) nextInstall() else refreshSoon()
            }
        }
    }

    // ---------- settings ----------
    fun changeThemeMode(v: Int) { themeMode = v; prefs.themeMode = v }
    fun changePalette(v: Int) { palette = v; prefs.palette = v }
    fun changeFilter(v: Int) { filter = v; prefs.filter = v }
    fun changeSort(v: Int) { sort = v; prefs.sort = v }

    // ---------- apps ----------
    fun visible(): List<AppItem> {
        val q = query.trim().lowercase()
        val f = allApps.filter {
            (filter == 2 || (filter == 1) == it.isSystem) &&
                (q.isEmpty() || it.name.lowercase().contains(q) || it.packageName.contains(q))
        }
        return when (sort) {
            1 -> f.sortedByDescending { it.apkSize }
            2 -> f.sortedByDescending { it.cacheSize }
            3 -> f.sortedByDescending { it.updateTime }
            else -> f.sortedBy { it.name.lowercase() }
        }
    }

    fun toggleSelect(pkg: String) {
        selected = if (pkg in selected) selected - pkg else selected + pkg
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            loading = true
            usageGranted = AppRepository.hasUsageAccess(app)
            val base = withContext(Dispatchers.IO) { AppRepository.loadBase(app) }
            allApps = base
            loading = false
            if (usageGranted) {
                val out = base.toMutableList()
                withContext(Dispatchers.IO) {
                    for (i in out.indices) {
                        ensureActive()
                        out[i] = AppRepository.withStats(app, out[i])
                        if (i % 40 == 39) allApps = out.toList()
                    }
                }
                allApps = out.toList()
            }
        }
    }

    private fun refreshSoon() {
        viewModelScope.launch { delay(700); refresh() }
    }

    // ---------- install ----------
    fun enqueueInstall(uris: List<Uri>) {
        installQueue.addAll(uris)
        if (!installing) nextInstall()
    }

    private fun nextInstall() {
        val u = installQueue.removeFirstOrNull()
        if (u == null) {
            installing = false
            refreshSoon()
            return
        }
        installing = true
        viewModelScope.launch {
            working = "Preparing install…"
            val r = runCatching { ApkInstaller.install(app, u) }
            working = null
            r.exceptionOrNull()?.let {
                toast.tryEmit("Install failed: ${it.message}")
                nextInstall()
            }
        }
    }

    // ---------- backup / restore ----------
    fun changeBackupTree(uri: Uri) {
        runCatching {
            app.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
        prefs.backupTree = uri.toString()
        backupTree = uri
        loadBackups()
    }

    fun loadBackups() {
        val tree = backupTree ?: run { backups = emptyList(); return }
        viewModelScope.launch {
            backups = withContext(Dispatchers.IO) { runCatching { Backups.list(app, tree) }.getOrDefault(emptyList()) }
        }
    }

    fun backupSelected(pkgs: Collection<String>) {
        val tree = backupTree ?: run { toast.tryEmit("Choose a backup folder first"); return }
        val items = allApps.filter { it.packageName in pkgs }
        if (items.isEmpty()) return
        viewModelScope.launch {
            var ok = 0
            for ((i, a) in items.withIndex()) {
                working = "Backing up ${a.name} (${i + 1}/${items.size})"
                val r = withContext(Dispatchers.IO) { runCatching { Backups.backup(app, a, tree) } }
                if (r.isSuccess) ok++
            }
            working = null
            selected = emptySet()
            toast.tryEmit("Backed up $ok of ${items.size} app(s)")
            loadBackups()
        }
    }

    fun deleteBackup(e: FileEntry) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { Backups.delete(app, e.uri) }
            toast.tryEmit(if (ok) "Deleted ${e.name}" else "Could not delete")
            loadBackups()
        }
    }

    // ---------- scan for installable files ----------
    fun scanFolder(tree: Uri) = runScan { Scanner.scanTree(app, tree) }
    fun scanStorage() = runScan { Scanner.scanStorage() }

    private fun runScan(block: () -> List<FileEntry>) {
        viewModelScope.launch {
            scanning = true
            found = withContext(Dispatchers.IO) { runCatching(block).getOrDefault(emptyList()) }
            scanning = false
            if (found.isEmpty()) toast.tryEmit("No APK files found")
        }
    }
}
