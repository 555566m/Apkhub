# APK Hub

Lightweight, modern APK installer & manager for Android (Kotlin + Jetpack Compose, Material 3).

## Features
- **Install** APK / APKS / XAPK / APKM from any folder — pick files, scan a folder, scan the whole phone, or open an `.apk` straight from your file manager
- **Backup & Restore** installed apps (split apps are saved as `.apks`) to a folder you choose
- **App list** with APK size, **cache** and data size, search, filter (user/system) and sort
- **Uninstall** one app or many at once (long-press to multi-select)
- **Themes**: System / Light / Dark / AMOLED + Material You + 6 accent palettes
- Small APK: no third-party libraries, R8 + resource shrinking

## Build
Push to GitHub — the workflow in `.github/workflows/build.yml` builds the APK.
Download it from **Actions → latest run → Artifacts → APK-Hub**.
Push a tag like `v1.0.0` to also publish a GitHub Release.

Local build: `gradle assembleRelease` (Gradle 8.9, JDK 17, Android SDK 34).

### Own signing key (optional)
Add repo secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Without them the release APK is signed with the debug key (installable, but not for Play Store).

## Notes
- Cache/data size needs **Usage access** (Settings tab → Grant access).
- Android does not let normal apps clear other apps' cache; "App info / clear cache" opens the system screen for that.
- "Scan phone" needs *All files access*. On Android 10 use "Scan folder".
- XAPK OBB expansion files are not copied.
